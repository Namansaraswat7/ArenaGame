package lld.game.exception;

public class ArenaException extends RuntimeException {
    public ArenaException(String message) {
        super(message);
    }
}
